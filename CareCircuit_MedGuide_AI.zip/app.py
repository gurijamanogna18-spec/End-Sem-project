import html
import json
from pathlib import Path

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

from src.ai_classifier import classify_instruction
from src.ocr_reader import extract_text_from_image
from src.prescription_parser import parse_prescription
from src.reminder_store import (
    add_reminder,
    clear_reminders,
    delete_reminder,
    get_reminders,
    get_history,
    sync_history,
    acknowledge_history_event,
    init_db,
)


ROOT = Path(__file__).resolve().parent
DEMO_FILE = ROOT / "data" / "sample_prescription.txt"

st.set_page_config(
    page_title="MedGuide AI | CareCircuit",
    page_icon="💊",
    layout="wide",
)

CSS_FILE = ROOT / "frontend" / "style.css"
if CSS_FILE.exists():
    st.markdown(
        f"<style>{CSS_FILE.read_text(encoding='utf-8')}</style>",
        unsafe_allow_html=True,
    )


init_db()
sync_history()  # Create today's history rows and update overdue statuses when the app opens.

# Simple interface localization: English, Hindi, and Telugu.
TRANSLATIONS = {
    "Hindi": {
        "💊 MedGuide AI": "💊 मेडगाइड AI",
        "📄 Prescription Reader": "📄 प्रिस्क्रिप्शन रीडर",
        "⏰ Reminders": "⏰ दवा रिमाइंडर",
        "📈 Medicine History": "📈 दवा इतिहास",
        "🤝 Caregiver Dashboard": "🤝 देखभालकर्ता डैशबोर्ड",
        "♿ Accessibility": "♿ सुलभता",
        "🤖 AI Demo": "🤖 AI डेमो",
        "Accessible prescription reader": "सुलभ प्रिस्क्रिप्शन रीडर",
        "Upload a prescription image": "प्रिस्क्रिप्शन की तस्वीर अपलोड करें",
        "Use a clear, well-lit image for better OCR.": "बेहतर OCR के लिए साफ़ और अच्छी रोशनी वाली तस्वीर इस्तेमाल करें।",
        "🔎 Read prescription with OCR": "🔎 OCR से प्रिस्क्रिप्शन पढ़ें",
        "Demo mode": "डेमो मोड",
        "Load demo prescription": "डेमो प्रिस्क्रिप्शन लोड करें",
        "Extracted text": "निकाला गया टेक्स्ट",
        "OCR result — verify before using": "OCR परिणाम — उपयोग से पहले जाँचें",
        "Detected medicines": "पहचानी गई दवाएँ",
        "Medicine reminder dashboard": "दवा रिमाइंडर डैशबोर्ड",
        "Add reminder times exactly as instructed by the prescription/clinician.": "प्रिस्क्रिप्शन/चिकित्सक के निर्देश के अनुसार ही रिमाइंडर समय जोड़ें।",
        "➕ Set a reminder manually": "➕ मैन्युअल रूप से रिमाइंडर सेट करें",
        "Medicine name": "दवा का नाम",
        "Enter medicine name": "दवा का नाम दर्ज करें",
        "Dose / strength (optional)": "खुराक / शक्ति (वैकल्पिक)",
        "As written on the prescription": "जैसा प्रिस्क्रिप्शन में लिखा है",
        "Alarm time": "अलार्म का समय",
        "Frequency (optional)": "आवृत्ति (वैकल्पिक)",
        "As prescribed, e.g. daily": "निर्देशानुसार, जैसे रोज़ाना",
        "Duration (optional)": "अवधि (वैकल्पिक)",
        "Notes (optional)": "नोट्स (वैकल्पिक)",
        "e.g. after food": "जैसे भोजन के बाद",
        "Save manual reminder": "मैन्युअल रिमाइंडर सेव करें",
        "Please enter a medicine name.": "कृपया दवा का नाम दर्ज करें।",
        "Saved reminders": "सेव किए गए रिमाइंडर",
        "🔔 Live alarm notifications": "🔔 लाइव अलार्म सूचनाएँ",
        "⬇️ Download reminders CSV": "⬇️ रिमाइंडर CSV डाउनलोड करें",
        "Reminder ID to delete": "हटाने के लिए रिमाइंडर ID",
        "🗑️ Delete selected reminder": "🗑️ चुना हुआ रिमाइंडर हटाएँ",
        "Clear all reminders": "सभी रिमाइंडर हटाएँ",
        "No reminders yet. Add one from a detected medicine.": "अभी कोई रिमाइंडर नहीं है। पहचानी गई दवा से एक जोड़ें।",
        "Medicine history": "दवा इतिहास",
        "From date": "शुरुआती तारीख",
        "To date": "अंतिम तारीख",
        "Scheduled": "निर्धारित",
        "Acknowledged": "स्वीकृत",
        "Missed": "छूटा हुआ",
        "✓ Mark as acknowledged": "✓ स्वीकृत के रूप में चिह्नित करें",
        "Acknowledgement recorded.": "स्वीकृति दर्ज की गई।",
        "Export medicine history CSV": "दवा इतिहास CSV निर्यात करें",
        "Caregiver dashboard": "देखभालकर्ता डैशबोर्ड",
        "Needs attention": "ध्यान देने की आवश्यकता",
        "Recent reminder activity": "हाल की रिमाइंडर गतिविधि",
        "Export caregiver activity CSV": "देखभालकर्ता गतिविधि CSV निर्यात करें",
        "Accessibility mode": "सुलभता मोड",
        "Design choices": "डिज़ाइन सुविधाएँ",
        "Enter an instruction phrase": "निर्देश वाक्यांश दर्ज करें",
        "Run AI classifier": "AI क्लासिफ़ायर चलाएँ",
        "System architecture": "सिस्टम आर्किटेक्चर",
        "Read aloud": "ज़ोर से पढ़ें",
    },
    "Telugu": {
        "💊 MedGuide AI": "💊 మెడ్‌గైడ్ AI",
        "📄 Prescription Reader": "📄 ప్రిస్క్రిప్షన్ రీడర్",
        "⏰ Reminders": "⏰ మందుల రిమైండర్లు",
        "📈 Medicine History": "📈 మందుల చరిత్ర",
        "🤝 Caregiver Dashboard": "🤝 సంరక్షకుల డ్యాష్‌బోర్డ్",
        "♿ Accessibility": "♿ అందుబాటు",
        "🤖 AI Demo": "🤖 AI డెమో",
        "Accessible prescription reader": "అందుబాటులో ఉండే ప్రిస్క్రిప్షన్ రీడర్",
        "Upload a prescription image": "ప్రిస్క్రిప్షన్ చిత్రాన్ని అప్‌లోడ్ చేయండి",
        "Use a clear, well-lit image for better OCR.": "మంచి OCR కోసం స్పష్టమైన, మంచి వెలుతురులో తీసిన చిత్రాన్ని ఉపయోగించండి.",
        "🔎 Read prescription with OCR": "🔎 OCRతో ప్రిస్క్రిప్షన్ చదవండి",
        "Demo mode": "డెమో మోడ్",
        "Load demo prescription": "డెమో ప్రిస్క్రిప్షన్ లోడ్ చేయండి",
        "Extracted text": "సేకరించిన వచనం",
        "OCR result — verify before using": "OCR ఫలితం — ఉపయోగించే ముందు తనిఖీ చేయండి",
        "Detected medicines": "గుర్తించిన మందులు",
        "Medicine reminder dashboard": "మందుల రిమైండర్ డ్యాష్‌బోర్డ్",
        "Add reminder times exactly as instructed by the prescription/clinician.": "ప్రిస్క్రిప్షన్/వైద్యుడు సూచించిన సమయాలనే నమోదు చేయండి.",
        "➕ Set a reminder manually": "➕ రిమైండర్‌ను మాన్యువల్‌గా సెట్ చేయండి",
        "Medicine name": "మందు పేరు",
        "Enter medicine name": "మందు పేరు నమోదు చేయండి",
        "Dose / strength (optional)": "మోతాదు / బలం (ఐచ్ఛికం)",
        "As written on the prescription": "ప్రిస్క్రిప్షన్‌లో ఉన్నట్లుగా",
        "Alarm time": "అలారం సమయం",
        "Frequency (optional)": "తరచుదనం (ఐచ్ఛికం)",
        "As prescribed, e.g. daily": "సూచించిన విధంగా, ఉదా. రోజూ",
        "Duration (optional)": "వ్యవధి (ఐచ్ఛికం)",
        "Notes (optional)": "గమనికలు (ఐచ్ఛికం)",
        "e.g. after food": "ఉదా. భోజనం తర్వాత",
        "Save manual reminder": "మాన్యువల్ రిమైండర్‌ను సేవ్ చేయండి",
        "Please enter a medicine name.": "దయచేసి మందు పేరు నమోదు చేయండి.",
        "Saved reminders": "సేవ్ చేసిన రిమైండర్లు",
        "🔔 Live alarm notifications": "🔔 ప్రత్యక్ష అలారం నోటిఫికేషన్లు",
        "⬇️ Download reminders CSV": "⬇️ రిమైండర్ల CSV డౌన్‌లోడ్ చేయండి",
        "Reminder ID to delete": "తొలగించాల్సిన రిమైండర్ ID",
        "🗑️ Delete selected reminder": "🗑️ ఎంచుకున్న రిమైండర్‌ను తొలగించండి",
        "Clear all reminders": "అన్ని రిమైండర్లను తొలగించండి",
        "No reminders yet. Add one from a detected medicine.": "ఇంకా రిమైండర్లు లేవు. గుర్తించిన మందు నుంచి ఒకటి జోడించండి.",
        "Medicine history": "మందుల చరిత్ర",
        "From date": "ప్రారంభ తేదీ",
        "To date": "ముగింపు తేదీ",
        "Scheduled": "షెడ్యూల్ చేయబడింది",
        "Acknowledged": "గుర్తించబడింది",
        "Missed": "మిస్ అయింది",
        "✓ Mark as acknowledged": "✓ గుర్తించినట్లు నమోదు చేయండి",
        "Acknowledgement recorded.": "గుర్తింపు నమోదు చేయబడింది.",
        "Export medicine history CSV": "మందుల చరిత్ర CSV ఎగుమతి చేయండి",
        "Caregiver dashboard": "సంరక్షకుల డ్యాష్‌బోర్డ్",
        "Needs attention": "శ్రద్ధ అవసరం",
        "Recent reminder activity": "ఇటీవలి రిమైండర్ కార్యకలాపాలు",
        "Export caregiver activity CSV": "సంరక్షకుల కార్యకలాపాల CSV ఎగుమతి చేయండి",
        "Accessibility mode": "అందుబాటు మోడ్",
        "Design choices": "డిజైన్ లక్షణాలు",
        "Enter an instruction phrase": "సూచన వాక్యాన్ని నమోదు చేయండి",
        "Run AI classifier": "AI క్లాసిఫైయర్‌ను అమలు చేయండి",
        "System architecture": "సిస్టమ్ నిర్మాణం",
        "Read aloud": "గట్టిగా చదవండి",
    }
}

# The selector stays in English so it is easy to find regardless of chosen language.
language = st.sidebar.selectbox("🌐 Language / భాష / भाषा", ["English", "Hindi", "Telugu"], index=0, key="ui_language")

def _translate(value):
    if language == "English":
        return value
    table = TRANSLATIONS.get(language, {})
    if isinstance(value, str):
        return table.get(value, value)
    if isinstance(value, (list, tuple)):
        return type(value)(_translate(item) for item in value)
    return value

# Translate common Streamlit labels, headings, tabs, and status text consistently.
def _install_translation_wrapper(name):
    original = getattr(st, name, None)
    if original is None:
        return
    def wrapped(*args, **kwargs):
        args = list(args)
        if args:
            args[0] = _translate(args[0])
        for key in ("label", "placeholder", "help"):
            if key in kwargs:
                kwargs[key] = _translate(kwargs[key])
        return original(*args, **kwargs)
    setattr(st, name, wrapped)

for _method in (
    "title", "header", "subheader", "write", "markdown", "caption", "text",
    "info", "success", "warning", "error", "exception", "tabs", "button",
    "text_input", "text_area", "time_input", "date_input", "selectbox",
    "multiselect", "radio", "checkbox", "download_button", "file_uploader",
    "form_submit_button", "metric", "number_input"
):
    _install_translation_wrapper(_method)

if "ocr_text" not in st.session_state:
    st.session_state.ocr_text = ""
if "parsed" not in st.session_state:
    st.session_state.parsed = []


def speech_button(text: str, button_id: str) -> None:
    safe_text = html.escape(text).replace("\n", " ")
    components.html(
        f"""
        <button
            onclick="window.speechSynthesis.cancel();
                     const u = new SpeechSynthesisUtterance('{safe_text}');
                     u.rate = 0.85;
                     window.speechSynthesis.speak(u);"
            style="padding:10px 16px;border-radius:8px;border:1px solid #888;
                   background:white;cursor:pointer;font-size:16px;">
            🔊 Read aloud
        </button>
        """,
        height=50,
    )


st.markdown('<div class="main-title">💊 MedGuide AI</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="subtitle">CareCircuit • Smart Medicine Reminder & Accessible Prescription Reader</div>',
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="safe-box">
    <b>Prototype safety notice:</b> MedGuide AI is a hackathon prototype.
    OCR and parsing can make mistakes. Always verify the original prescription
    with a doctor or pharmacist before taking any medicine.
    </div>
    """,
    unsafe_allow_html=True,
)

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
    ["📄 Prescription Reader", "⏰ Reminders", "📈 Medicine History", "🤝 Caregiver Dashboard", "♿ Accessibility", "🤖 AI Demo"]
)

with tab1:
    st.header("Accessible prescription reader")

    col1, col2 = st.columns([2, 1])

    with col1:
        uploaded = st.file_uploader(
            "Upload a prescription image",
            type=["png", "jpg", "jpeg"],
            help="Use a clear, well-lit image for better OCR.",
        )

        if uploaded:
            st.image(uploaded, caption="Uploaded prescription", width=500)

            if st.button("🔎 Read prescription with OCR", type="primary"):
                text, message = extract_text_from_image(uploaded)
                st.session_state.ocr_text = text
                st.session_state.parsed = parse_prescription(text) if text else []
                if text:
                    st.success(message)
                else:
                    st.warning(message)

    with col2:
        st.subheader("Demo mode")
        if st.button("Load demo prescription"):
            demo_text = DEMO_FILE.read_text(encoding="utf-8")
            st.session_state.ocr_text = demo_text
            st.session_state.parsed = parse_prescription(demo_text)
            st.success("Demo prescription loaded.")

    if st.session_state.ocr_text:
        st.subheader("Extracted text")
        st.text_area(
            "OCR result — verify before using",
            st.session_state.ocr_text,
            height=220,
        )
        speech_button(st.session_state.ocr_text, "read-ocr")

    if st.session_state.parsed:
        st.subheader("Detected medicines")
        df = pd.DataFrame(st.session_state.parsed)
        display_columns = [
            "medicine",
            "dose",
            "frequency",
            "duration",
            "instruction",
            "frequency_slots",
            "ocr_match_score",
            "ai_instruction_class",
            "ai_confidence",
        ]
        st.dataframe(
            df[display_columns],
            use_container_width=True,
            hide_index=True,
        )

        st.info(
            "The AI classifier labels instruction wording only. "
            "It does not prescribe a dose or decide whether a medicine is appropriate."
        )

with tab2:
    st.header("Medicine reminder dashboard")
    st.write("Add reminder times exactly as instructed by the prescription/clinician.")

    parsed = st.session_state.parsed

    st.subheader("➕ Set a reminder manually")
    st.caption("You can create a reminder even if you have not uploaded a prescription. Enter only the schedule confirmed by your prescription or clinician.")
    with st.form("manual_reminder_form"):
        manual_col1, manual_col2 = st.columns(2)
        with manual_col1:
            manual_medicine = st.text_input("Medicine name", placeholder="Enter medicine name")
            manual_dose = st.text_input("Dose / strength (optional)", placeholder="As written on the prescription")
            manual_time = st.time_input("Alarm time", key="manual_alarm_time")
        with manual_col2:
            manual_frequency = st.text_input("Frequency (optional)", placeholder="As prescribed, e.g. daily")
            manual_duration = st.text_input("Duration (optional)", placeholder="As prescribed")
            manual_notes = st.text_input("Notes (optional)", placeholder="e.g. after food")
        manual_submitted = st.form_submit_button("Save manual reminder", type="primary")
        if manual_submitted:
            if not manual_medicine.strip():
                st.error("Please enter a medicine name.")
            else:
                add_reminder(
                    medicine=manual_medicine.strip(),
                    dose=manual_dose.strip(),
                    time=manual_time.strftime("%H:%M"),
                    frequency=manual_frequency.strip(),
                    duration=manual_duration.strip(),
                    notes=manual_notes.strip(),
                )
                st.success(f"Reminder saved for {manual_time.strftime('%I:%M %p')}. Keep this website open and enable the alarm monitor below.")
                st.rerun()

    if parsed:
        st.subheader("Add from detected prescription")
        selected = st.selectbox(
            "Medicine",
            options=range(len(parsed)),
            format_func=lambda i: (
                f"{parsed[i]['medicine']} {parsed[i]['dose']}".strip()
            ),
        )
        item = parsed[selected]

        with st.form("reminder_form"):
            reminder_time = st.time_input("Reminder time")
            notes = st.text_input(
                "Notes",
                value=item["instruction"],
                placeholder="Example: after food",
            )
            submitted = st.form_submit_button("➕ Save reminder")

            if submitted:
                add_reminder(
                    medicine=item["medicine"],
                    dose=item["dose"],
                    time=reminder_time.strftime("%H:%M"),
                    frequency=item["frequency"],
                    duration=item["duration"],
                    notes=notes,
                )
                st.success("Reminder saved.")

    st.subheader("Saved reminders")
    reminders = get_reminders()

    # Browser-side alarm monitor. It works while this page is open; it is not a
    # background service and cannot alert if the browser/device is shut down.
    st.markdown("### 🔔 Live alarm notifications")
    st.caption(
        "Keep this website open. Click Enable below once to allow sound and browser "
        "notifications. Your browser may ask for notification permission."
    )
    alarm_payload = json.dumps([
        {
            "id": int(r["id"]),
            "time": str(r["time"]),
            "medicine": str(r["medicine"]),
            "dose": str(r.get("dose") or ""),
            "notes": str(r.get("notes") or ""),
        }
        for r in reminders
    ]).replace("</", "<\\/")
    alarm_ui = {
        "English": {"title": "Alarm monitor", "not_enabled": "Notifications are not enabled yet.", "enable": "Enable notifications and sound", "enabled": "Alarms enabled", "due": "Reminder due: ", "next": "Next reminder today: ", "none_today": "No more reminders scheduled for today.", "add": "Add a reminder above to activate alarms."},
        "Hindi": {"title": "अलार्म मॉनिटर", "not_enabled": "सूचनाएँ अभी सक्षम नहीं हैं।", "enable": "सूचनाएँ और ध्वनि सक्षम करें", "enabled": "अलार्म सक्षम हैं", "due": "रिमाइंडर का समय: ", "next": "आज अगला रिमाइंडर: ", "none_today": "आज के लिए कोई और रिमाइंडर नहीं है।", "add": "अलार्म चालू करने के लिए ऊपर रिमाइंडर जोड़ें।"},
        "Telugu": {"title": "అలారం మానిటర్", "not_enabled": "నోటిఫికేషన్లు ఇంకా ప్రారంభించబడలేదు.", "enable": "నోటిఫికేషన్లు మరియు శబ్దాన్ని ప్రారంభించండి", "enabled": "అలారాలు ప్రారంభించబడ్డాయి", "due": "రిమైండర్ సమయం: ", "next": "ఈరోజు తదుపరి రిమైండర్: ", "none_today": "ఈరోజుకు మరిన్ని రిమైండర్లు లేవు.", "add": "అలారాలను ప్రారంభించడానికి పైభాగంలో రిమైండర్ జోడించండి."}
    }.get(language, {})
    alarm_title = json.dumps(alarm_ui.get("title", "Alarm monitor"), ensure_ascii=False)
    alarm_not_enabled = json.dumps(alarm_ui.get("not_enabled", "Notifications are not enabled yet."), ensure_ascii=False)
    alarm_enable = json.dumps(alarm_ui.get("enable", "Enable notifications and sound"), ensure_ascii=False)
    alarm_enabled = json.dumps(alarm_ui.get("enabled", "Alarms enabled"), ensure_ascii=False)
    alarm_due = json.dumps(alarm_ui.get("due", "Reminder due: "), ensure_ascii=False)
    alarm_next = json.dumps(alarm_ui.get("next", "Next reminder today: "), ensure_ascii=False)
    alarm_none_today = json.dumps(alarm_ui.get("none_today", "No more reminders scheduled for today."), ensure_ascii=False)
    alarm_add = json.dumps(alarm_ui.get("add", "Add a reminder above to activate alarms."), ensure_ascii=False)
    components.html(
        f"""
        <div style="font-family:Arial,sans-serif;border:1px solid #d8e4ef;border-radius:12px;padding:14px;background:#f7fbff;color:#17324d">
          <div style="font-weight:700;font-size:15px;margin-bottom:6px">{alarm_ui.get("title", "Alarm monitor")}</div>
          <div id="alarm-status" style="font-size:13px;margin-bottom:10px">{alarm_ui.get("not_enabled", "Notifications are not enabled yet.")}</div>
          <button id="enable-alarm" style="background:#087f8c;color:white;border:0;border-radius:8px;padding:10px 14px;font-weight:700;cursor:pointer">{alarm_ui.get("enable", "Enable notifications and sound")}</button>
          <div id="next-alarm" style="font-size:12px;margin-top:10px;color:#52677c"></div>
        </div>
        <script>
          const reminders = {alarm_payload};
          const statusEl = document.getElementById('alarm-status');
          const nextEl = document.getElementById('next-alarm');
          const enableBtn = document.getElementById('enable-alarm');
          let enabled = false;
          let audioCtx = null;
          const fired = new Set();
          function beep() {{
            try {{
              if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
              if (audioCtx.state === 'suspended') audioCtx.resume();
              const osc = audioCtx.createOscillator();
              const gain = audioCtx.createGain();
              osc.type = 'sine'; osc.frequency.value = 880;
              gain.gain.setValueAtTime(0.001, audioCtx.currentTime);
              gain.gain.exponentialRampToValueAtTime(0.18, audioCtx.currentTime + 0.03);
              gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);
              osc.connect(gain); gain.connect(audioCtx.destination);
              osc.start(); osc.stop(audioCtx.currentTime + 0.62);
            }} catch (e) {{ console.log('Audio alert unavailable', e); }}
          }}
          function notify(r) {{
            const title = 'MedGuide AI medicine reminder';
            const body = (r.medicine + (r.dose ? ' ' + r.dose : '') + ' is scheduled now. ' + (r.notes || '')).trim();
            if ('Notification' in window && Notification.permission === 'granted') {{
              try {{ new Notification(title, {{ body: body, tag: 'medguide-' + r.id }}); }} catch(e) {{}}
            }}
            beep();
            statusEl.textContent = {alarm_due} + r.medicine + ' at ' + r.time + '. Please check the reminder list.';
          }}
          enableBtn.addEventListener('click', async () => {{
            enabled = true;
            try {{
              audioCtx = new (window.AudioContext || window.webkitAudioContext)();
              await audioCtx.resume();
              if ('Notification' in window && Notification.permission === 'default') await Notification.requestPermission();
              if ('Notification' in window && Notification.permission === 'granted') {{
                statusEl.textContent = 'Alarms enabled. Keep this website open for scheduled alerts.';
              }} else {{
                statusEl.textContent = 'Sound alarms enabled. Browser notifications are blocked or unsupported; allow them in browser site settings if desired.';
              }}
              beep();
            }} catch (e) {{
              statusEl.textContent = 'Alarm permission could not be enabled here. Keep the page open and check browser permissions.';
            }}
            enableBtn.textContent = {alarm_enabled};
          }});
          function checkAlarms() {{
            const now = new Date();
            const hhmm = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
            const day = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0') + '-' + String(now.getDate()).padStart(2,'0');
            const upcoming = reminders.filter(r => r.time >= hhmm).sort((a,b) => a.time.localeCompare(b.time))[0];
            nextEl.textContent = upcoming ? ({alarm_next} + upcoming.medicine + ' at ' + upcoming.time) : (reminders.length ? {alarm_none_today} : {alarm_add});
            if (!enabled) return;
            reminders.forEach(r => {{
              const key = day + '-' + r.id + '-' + r.time;
              if (r.time === hhmm && !fired.has(key)) {{ fired.add(key); notify(r); }}
            }});
          }}
          checkAlarms();
          setInterval(checkAlarms, 5000);
        </script>
        """,
        height=180,
        scrolling=False,
    )

    if reminders:
        reminder_df = pd.DataFrame(reminders)
        st.dataframe(
            reminder_df[
                ["id", "time", "medicine", "dose", "frequency", "duration", "notes"]
            ],
            use_container_width=True,
            hide_index=True,
        )

        speech_text = "\n".join(
            f"{r['time']}: {r['medicine']} {r['dose']}".strip()
            for r in reminders
        )
        speech_button(speech_text, "read-reminders")

        csv = reminder_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            "⬇️ Download reminders CSV",
            data=csv,
            file_name="carecircuit_reminders.csv",
            mime="text/csv",
        )

        delete_id = st.number_input(
            "Reminder ID to delete",
            min_value=1,
            step=1,
            value=int(reminders[0]["id"]),
        )
        if st.button("🗑️ Delete selected reminder"):
            delete_reminder(int(delete_id))
            st.success("Reminder deleted. Refreshing...")
            st.rerun()

        if st.button("Clear all reminders"):
            clear_reminders()
            st.success("All reminders cleared.")
            st.rerun()
    else:
        st.info("No reminders yet. Add one from a detected medicine.")

with tab3:
    st.header("Medicine history")
    st.write(
        "Review reminder events and record when an alert has been acknowledged. "
        "History status is updated when this app is opened or refreshed."
    )

    from datetime import date, timedelta
    history_col1, history_col2 = st.columns(2)
    with history_col1:
        history_start = st.date_input("From date", value=date.today() - timedelta(days=30), key="history_start")
    with history_col2:
        history_end = st.date_input("To date", value=date.today(), key="history_end")

    if history_start > history_end:
        st.error("The start date must be on or before the end date.")
        history_rows = []
    else:
        history_rows = get_history(history_start, history_end)

    if history_rows:
        history_df = pd.DataFrame(history_rows)
        status_counts = history_df["status"].value_counts().to_dict()
        m1, m2, m3 = st.columns(3)
        m1.metric("Scheduled", int(status_counts.get("Scheduled", 0)))
        m2.metric("Acknowledged", int(status_counts.get("Acknowledged", 0)))
        m3.metric("Missed", int(status_counts.get("Missed", 0)))
        st.dataframe(
            history_df[["event_date", "scheduled_time", "medicine", "dose", "status", "acknowledged_at", "notes"]],
            use_container_width=True,
            hide_index=True,
        )

        eligible = [r for r in history_rows if r["status"] != "Acknowledged"]
        if eligible:
            selected_event = st.selectbox(
                "Select an alert to acknowledge",
                options=[r["id"] for r in eligible],
                format_func=lambda event_id: next(
                    f"{r['event_date']} · {r['scheduled_time']} · {r['medicine']} ({r['status']})"
                    for r in eligible if r["id"] == event_id
                ),
                key="history_ack_select",
            )
            if st.button("✓ Mark as acknowledged", type="primary"):
                if acknowledge_history_event(int(selected_event)):
                    st.success("Acknowledgement recorded.")
                    st.rerun()
                else:
                    st.info("This event was already acknowledged.")
        st.download_button(
            "⬇️ Export medicine history CSV",
            data=history_df.to_csv(index=False).encode("utf-8"),
            file_name="medguide_medicine_history.csv",
            mime="text/csv",
        )
    else:
        st.info("No reminder history found for this date range. Add a reminder and refresh the app to create today's history.")

    st.caption(
        "Status meanings: Scheduled = planned; Acknowledged = a user recorded a response; "
        "Missed = not acknowledged within the configured 60-minute grace period. "
        "Acknowledgement does not confirm medicine ingestion."
    )

with tab4:
    st.header("Caregiver dashboard")
    st.write(
        "A consolidated view for a caregiver to review reminder activity and identify "
        "alerts that may need follow-up."
    )
    st.warning(
        "Demo privacy note: this prototype has no login or role-based access control. "
        "Use sample data only; do not expose real patient information on a shared device."
    )

    caregiver_history = get_history()
    if caregiver_history:
        caregiver_df = pd.DataFrame(caregiver_history)
        totals = caregiver_df["status"].value_counts().to_dict()
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total events", len(caregiver_df))
        c2.metric("Scheduled", int(totals.get("Scheduled", 0)))
        c3.metric("Acknowledged", int(totals.get("Acknowledged", 0)))
        c4.metric("Missed", int(totals.get("Missed", 0)))

        st.subheader("Needs attention")
        needs_attention = caregiver_df[caregiver_df["status"].isin(["Missed", "Scheduled"])]
        if not needs_attention.empty:
            st.dataframe(
                needs_attention[["event_date", "scheduled_time", "medicine", "dose", "status", "notes"]],
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.success("No unacknowledged events are currently listed in the recorded history.")

        st.subheader("Recent reminder activity")
        st.dataframe(
            caregiver_df.head(50)[["event_date", "scheduled_time", "medicine", "dose", "status", "acknowledged_at"]],
            use_container_width=True,
            hide_index=True,
        )
        st.download_button(
            "⬇️ Export caregiver activity CSV",
            data=caregiver_df.to_csv(index=False).encode("utf-8"),
            file_name="medguide_caregiver_activity.csv",
            mime="text/csv",
        )
    else:
        st.info("No history is available yet. Add a reminder to begin recording daily activity.")

    st.caption(
        "Caregiver view is read-only except for the shared acknowledgement workflow. "
        "Caregiver notifications are not sent by this local prototype."
    )

with tab5:
    st.header("Accessibility mode")
    st.markdown(
        """
        ### Design choices

        - Large, high-contrast interface
        - Clear labels instead of icon-only controls
        - Extracted prescription text can be read aloud
        - Reminder list can be read aloud
        - Simple table layout for medicine details
        - Browser speech synthesis requires no extra Python package
        """
    )

    accessibility_text = (
        "MedGuide AI accessibility demo. "
        "The application reads prescription text and reminders aloud "
        "using your browser's speech synthesis."
    )
    speech_button(accessibility_text, "read-accessibility")

with tab6:
    st.header("🤖 AI / ML demonstration")

    instruction = st.text_input(
        "Enter an instruction phrase",
        value="take after breakfast",
    )

    if st.button("Run AI classifier"):
        label, confidence = classify_instruction(instruction)
        st.metric("Predicted reminder category", label)
        st.metric("Model confidence", f"{confidence * 100:.1f}%")
        st.caption(
            "This is a small demonstration classifier trained on example phrases. "
            "It is not a medical decision system."
        )

    st.subheader("System architecture")
    st.code(
        """
Prescription image
      ↓
Tesseract OCR
      ↓
Text cleaning + medicine matching
      ↓
Instruction parser
      ↓
Small ML classifier
      ↓
Reminder database (SQLite)
      ↓
Dashboard + Read Aloud + CSV
      ↓
Future ESP32 / buzzer / OLED integration
        """,
        language="text",
    )

st.divider()
st.caption(
    "CareCircuit • MedGuide AI • AI Bots-2026 Healthcare Track • "
    "Hackathon prototype — verify all medication details before use."
)
