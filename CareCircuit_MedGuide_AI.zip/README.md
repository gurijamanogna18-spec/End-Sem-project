# CareCircuit — MedGuide AI

**Hackathon project:** AI Bots-2026, Healthcare Track  
**Team:** CareCircuit  
**Project:** MedGuide AI — Smart Medicine Reminder and Accessible Prescription Reader

## What this prototype does

1. Reads a prescription image using OCR (Tesseract).
2. Extracts medicine names, dose, frequency and duration using a transparent parser.
3. Uses a small ML text classifier to categorize *instruction wording* into reminder slots.
4. Lets the user create and manage medicine reminders, including manual entry.
5. Provides browser-side sound alarms and browser notifications for scheduled reminders while the website remains open.
5. Provides a browser-based **Read Aloud** accessibility feature.
6. Exports the reminder list to CSV.
7. Stores reminders locally in SQLite for a simple offline demo.

> **Safety:** This is a hackathon prototype, not a medical device and not a substitute for a doctor/pharmacist. OCR and parsing can be wrong. Always verify medicine name, strength, dose, frequency, duration and timing against the original prescription before taking a medicine. The app does not diagnose conditions or recommend medicines.

## Recommended stack

- Python 3.10+
- Streamlit
- Tesseract OCR + pytesseract
- scikit-learn
- RapidFuzz
- SQLite
- HTML5 browser speech synthesis

## VS Code setup — Windows

### 1. Open the project

Open this folder in VS Code:

```text
CareCircuit_MedGuide_AI
```

### 2. Create a virtual environment

PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\Activate.ps1
```

### 3. Install Python packages

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Install Tesseract OCR

The Python package `pytesseract` is only a Python wrapper. Tesseract itself must also be installed on Windows.

After installing Tesseract, if it is not detected automatically, set the environment variable:

```powershell
$env:TESSERACT_CMD="C:\Program Files\Tesseract-OCR\tesseract.exe"
```

Then start the app from the same terminal.

### 5. Run

```powershell
streamlit run app.py
```

The browser will open the MedGuide AI dashboard.

## Quick demo without OCR

You can click **Load demo prescription** inside the app. This works even before Tesseract is installed, so the team can demonstrate the parser, AI classifier, reminders and accessibility feature.

## Project structure

```text
CareCircuit_MedGuide_AI/
│
├── app.py
├── requirements.txt
├── README.md
│
├── src/
│   ├── __init__.py
│   ├── ai_classifier.py
│   ├── ocr_reader.py
│   ├── prescription_parser.py
│   └── reminder_store.py
│
└── data/
    ├── medicines.json
    └── sample_prescription.txt
```

## 24-hour hackathon demo flow

1. Open the dashboard.
2. Load the demo prescription.
3. Show extracted text.
4. Show detected medicines and fields.
5. Explain the ML instruction classifier and confidence score.
6. Add one medicine as a reminder manually or from the detected prescription.
7. Enable browser alarms and show the live alarm monitor; keep the page open for the demo.
8. Show the reminder dashboard.
8. Click **Read Aloud** and demonstrate accessibility.
9. Export the reminders as CSV.
10. Explain how an ESP32/buzzer/display can later consume the same reminder data.

## Important judging points

### Real problem
People can have difficulty reading small or handwritten prescriptions and remembering multiple doses.

### AI/ML
The prototype combines OCR with an ML classifier that maps instruction text to a reminder-slot category. The classifier is intentionally small and transparent so it can run locally.

### Accessibility
The dashboard uses large text, clear contrast, keyboard-friendly controls and browser speech synthesis.

### Privacy
The prototype processes data locally. Do not upload real patient prescriptions during the hackathon demo.

### Future hardware
A future CareCircuit hardware node can use:
- ESP32
- buzzer
- RGB/LED indicator
- OLED display
- push button for acknowledgement
- optional vibration motor

The Python app can later expose a REST/MQTT interface for that device.

## Language selection

Use the **Language / భాష / भाषा** selector in the left sidebar to switch the main interface between English, Hindi, and Telugu. The core navigation, reminder form, history/caregiver labels, and alarm monitor labels are localized. Some long explanatory text and medicine data may remain in English; medicine names and prescription content are intentionally not translated to avoid changing medical meaning.
