import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "medguide.db"
MISSED_GRACE_MINUTES = 60


def get_connection() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db() -> None:
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                medicine TEXT NOT NULL,
                dose TEXT,
                time TEXT NOT NULL,
                frequency TEXT,
                duration TEXT,
                notes TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        # Snapshot history keeps a record even if a reminder is later edited/deleted.
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS reminder_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                reminder_id INTEGER,
                event_date TEXT NOT NULL,
                scheduled_time TEXT NOT NULL,
                medicine TEXT NOT NULL,
                dose TEXT,
                notes TEXT,
                status TEXT NOT NULL DEFAULT 'Scheduled'
                    CHECK(status IN ('Scheduled', 'Acknowledged', 'Missed')),
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                acknowledged_at TEXT,
                UNIQUE(reminder_id, event_date)
            )
            """
        )
        conn.commit()


def add_reminder(
    medicine: str,
    dose: str,
    time: str,
    frequency: str,
    duration: str,
    notes: str,
) -> None:
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO reminders
            (medicine, dose, time, frequency, duration, notes)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (medicine, dose, time, frequency, duration, notes),
        )
        conn.commit()


def get_reminders() -> list[dict[str, Any]]:
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT id, medicine, dose, time, frequency, duration, notes, created_at
            FROM reminders
            ORDER BY time, medicine
            """
        ).fetchall()
    return [dict(row) for row in rows]


def sync_history(today: date | None = None) -> None:
    """Create today's history entries and mark overdue, unacknowledged entries as missed.

    This runs only when the app is opened/refreshed; it is not a background alarm service.
    """
    today = today or date.today()
    today_str = today.isoformat()
    now = datetime.now()
    with get_connection() as conn:
        reminders = conn.execute(
            "SELECT id, medicine, dose, time, notes FROM reminders"
        ).fetchall()
        for reminder in reminders:
            conn.execute(
                """
                INSERT OR IGNORE INTO reminder_history
                (reminder_id, event_date, scheduled_time, medicine, dose, notes, status)
                VALUES (?, ?, ?, ?, ?, ?, 'Scheduled')
                """,
                (
                    reminder["id"], today_str, reminder["time"], reminder["medicine"],
                    reminder["dose"], reminder["notes"]
                ),
            )

        # Update scheduled entries whose configured time has passed by the grace interval.
        rows = conn.execute(
            """
            SELECT id, event_date, scheduled_time FROM reminder_history
            WHERE status = 'Scheduled'
            """
        ).fetchall()
        for row in rows:
            try:
                due = datetime.strptime(
                    f"{row['event_date']} {row['scheduled_time']}", "%Y-%m-%d %H:%M"
                )
            except ValueError:
                continue
            if now >= due + timedelta(minutes=MISSED_GRACE_MINUTES):
                conn.execute(
                    "UPDATE reminder_history SET status = 'Missed' WHERE id = ? AND status = 'Scheduled'",
                    (row["id"],),
                )
        conn.commit()


def get_history(start_date: date | None = None, end_date: date | None = None) -> list[dict[str, Any]]:
    query = """
        SELECT id, reminder_id, event_date, scheduled_time, medicine, dose, notes,
               status, created_at, acknowledged_at
        FROM reminder_history
    """
    clauses = []
    params: list[str] = []
    if start_date:
        clauses.append("event_date >= ?")
        params.append(start_date.isoformat())
    if end_date:
        clauses.append("event_date <= ?")
        params.append(end_date.isoformat())
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY event_date DESC, scheduled_time DESC, medicine"
    with get_connection() as conn:
        rows = conn.execute(query, params).fetchall()
    return [dict(row) for row in rows]


def acknowledge_history_event(event_id: int) -> bool:
    with get_connection() as conn:
        cursor = conn.execute(
            """
            UPDATE reminder_history
            SET status = 'Acknowledged', acknowledged_at = CURRENT_TIMESTAMP
            WHERE id = ? AND status != 'Acknowledged'
            """,
            (event_id,),
        )
        conn.commit()
        return cursor.rowcount > 0


def delete_reminder(reminder_id: int) -> None:
    # Keep prior history snapshots; remove only the active recurring reminder.
    with get_connection() as conn:
        conn.execute("DELETE FROM reminders WHERE id = ?", (reminder_id,))
        conn.commit()


def clear_reminders() -> None:
    # Keep historical records intact for the history/caregiver views.
    with get_connection() as conn:
        conn.execute("DELETE FROM reminders")
        conn.commit()
