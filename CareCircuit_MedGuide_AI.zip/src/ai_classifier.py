from functools import lru_cache

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline


# This is a small demonstration model trained only on example instruction phrases.
# It classifies wording into a reminder-slot category. It does NOT decide dosage.
TRAINING_TEXTS = [
    "take in the morning",
    "take after breakfast",
    "morning dose",
    "take before breakfast",
    "take in the afternoon",
    "after lunch",
    "afternoon dose",
    "take at noon",
    "take in the evening",
    "after dinner",
    "night dose",
    "take at bedtime",
    "take with food",
    "after food",
    "take before food",
    "before meals",
]

TRAINING_LABELS = [
    "morning",
    "morning",
    "morning",
    "morning",
    "afternoon",
    "afternoon",
    "afternoon",
    "afternoon",
    "night",
    "night",
    "night",
    "night",
    "with_food",
    "with_food",
    "before_food",
    "before_food",
]


@lru_cache(maxsize=1)
def get_model() -> Pipeline:
    model = Pipeline(
        [
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), lowercase=True)),
            ("classifier", LogisticRegression(max_iter=1000, random_state=69)),
        ]
    )
    model.fit(TRAINING_TEXTS, TRAINING_LABELS)
    return model


def classify_instruction(text: str) -> tuple[str, float]:
    """
    Classify instruction wording.

    Returns:
        label, confidence
    """
    clean = (text or "").strip()
    if not clean:
        return "unknown", 0.0

    model = get_model()
    probabilities = model.predict_proba([clean])[0]
    index = probabilities.argmax()
    label = model.classes_[index]
    confidence = float(probabilities[index])
    return label, confidence
