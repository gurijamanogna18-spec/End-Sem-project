import json
import re
from pathlib import Path

from rapidfuzz import process, fuzz

from .ai_classifier import classify_instruction


ROOT = Path(__file__).resolve().parents[1]
MEDICINE_FILE = ROOT / "data" / "medicines.json"


def load_medicine_names() -> list[str]:
    with MEDICINE_FILE.open("r", encoding="utf-8") as file:
        data = json.load(file)
    return data.get("medicines", [])


def normalize_text(text: str) -> str:
    text = text.replace("—", "-").replace("–", "-")
    return re.sub(r"[ \t]+", " ", text).strip()


def extract_medicine(line: str, known_medicines: list[str]) -> tuple[str, float]:
    """Find a known medicine in a line using fuzzy matching."""
    for medicine in known_medicines:
        if re.search(rf"\b{re.escape(medicine)}\b", line, flags=re.IGNORECASE):
            return medicine, 100.0

    first_words = re.findall(r"[A-Za-z][A-Za-z-]{3,}", line)
    for word in first_words[:4]:
        match = process.extractOne(
            word,
            known_medicines,
            scorer=fuzz.WRatio,
            score_cutoff=82,
        )
        if match:
            return match[0], float(match[1])

    return "", 0.0


def parse_frequency(line: str) -> str:
    match = re.search(r"\b([01]-[01]-[01])\b", line)
    if match:
        return match.group(1)

    patterns = [
        (r"\b(once|one time|1 time)\b", "once daily"),
        (r"\b(twice|two times|2 times)\b", "twice daily"),
        (r"\b(thrice|three times|3 times)\b", "three times daily"),
    ]
    lower = line.lower()
    for pattern, result in patterns:
        if re.search(pattern, lower):
            return result
    return ""


def parse_duration(line: str) -> str:
    match = re.search(r"\b(\d+)\s*(day|days|week|weeks|month|months)\b", line, re.IGNORECASE)
    return match.group(0) if match else ""


def parse_dose(line: str) -> str:
    match = re.search(
        r"\b(\d+(?:\.\d+)?)\s*(mg|mcg|g|ml|mL|IU)\b",
        line,
        re.IGNORECASE,
    )
    return match.group(0) if match else ""


def parse_instruction(line: str) -> str:
    parts = [p.strip() for p in line.split(" - ") if p.strip()]
    if len(parts) >= 5:
        return " ".join(parts[4:])
    lower = line.lower()
    for phrase in [
        "after food",
        "before food",
        "with food",
        "after breakfast",
        "after lunch",
        "after dinner",
        "at night",
        "at bedtime",
        "in the morning",
        "in the afternoon",
        "in the evening",
    ]:
        if phrase in lower:
            return phrase
    return ""


def frequency_slots(frequency: str) -> list[str]:
    mapping = {
        "1-0-0": ["morning"],
        "0-1-0": ["afternoon"],
        "0-0-1": ["night"],
        "1-1-0": ["morning", "afternoon"],
        "1-0-1": ["morning", "night"],
        "0-1-1": ["afternoon", "night"],
        "1-1-1": ["morning", "afternoon", "night"],
    }
    return mapping.get(frequency, [])


def parse_prescription(text: str) -> list[dict]:
    known = load_medicine_names()
    results = []

    for raw_line in text.splitlines():
        line = normalize_text(raw_line)
        if not line:
            continue

        medicine, match_score = extract_medicine(line, known)
        if not medicine:
            continue

        frequency = parse_frequency(line)
        instruction = parse_instruction(line)
        ai_label, ai_confidence = classify_instruction(instruction or line)

        results.append(
            {
                "medicine": medicine,
                "dose": parse_dose(line),
                "frequency": frequency,
                "duration": parse_duration(line),
                "instruction": instruction,
                "frequency_slots": ", ".join(frequency_slots(frequency)),
                "ocr_match_score": round(match_score, 1),
                "ai_instruction_class": ai_label,
                "ai_confidence": round(ai_confidence * 100, 1),
                "source_line": line,
            }
        )

    return results
