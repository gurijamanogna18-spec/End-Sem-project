from io import BytesIO
import os

from PIL import Image, ImageOps, ImageFilter
import pytesseract


def preprocess_image(image: Image.Image) -> Image.Image:
    """Prepare an image for OCR without changing the source file."""
    img = image.convert("L")
    img = ImageOps.autocontrast(img)
    img = img.filter(ImageFilter.SHARPEN)
    return img


def get_tesseract_path() -> str | None:
    """Read an optional Windows Tesseract path from an environment variable."""
    return os.getenv("TESSERACT_CMD")


def extract_text_from_image(uploaded_file) -> tuple[str, str]:
    """
    OCR an uploaded image.

    Returns:
        (text, message)
    """
    try:
        image = Image.open(BytesIO(uploaded_file.getvalue()))
        processed = preprocess_image(image)

        tesseract_path = get_tesseract_path()
        if tesseract_path:
            pytesseract.pytesseract.tesseract_cmd = tesseract_path

        text = pytesseract.image_to_string(processed, config="--psm 6")
        if not text.strip():
            return "", "OCR completed, but no readable text was detected."
        return text.strip(), "OCR completed successfully."
    except pytesseract.pytesseract.TesseractNotFoundError:
        return "", (
            "Tesseract OCR was not found. Install Tesseract and set "
            "TESSERACT_CMD if required. You can still use 'Load demo prescription'."
        )
    except Exception as exc:
        return "", f"OCR error: {exc}"
